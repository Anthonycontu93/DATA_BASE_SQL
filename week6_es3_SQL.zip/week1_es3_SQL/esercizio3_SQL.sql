select * from impiegato where titolo_studio like "%Economia";

select * from impiegato as imp 
inner join servizio_impiegato as s_imp 
on imp.codice_fiscale  = s_imp.codice_fiscale 
where imp.titolo_studio like "Di% %matica" or s_imp.carica like "%sso%";

select * from servizio_impiegato where carica like "%mmesso%";

select carica from servizio_impiegato;