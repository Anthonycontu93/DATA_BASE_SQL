SELECT album.title, Track.albumId, COUNT(track.AlbumId) AS Num_Track
FROM Track
join album on album.AlbumId = Track.AlbumId
GROUP BY AlbumId
HAVING Num_Track > 20
Order by Num_Track  DESC;

-- query per capire quanti album e quante volte sono ripetuti in modo tale da avere il numero di canzoni 
select albumId, count(AlbumId) as conteggio_canzoni from track group by albumId;

select * from track where albumId = 42;