-- Cominciate facendo un’analisi esplorativa del database, ad esempio:
-- Fate un elenco di tutte le tabelle.
-- Visualizzate le prime 10 righe della tabella Album. 
-- Trovate il numero totale di canzoni della tabella Tracks. 
-- Trovate i diversi generi presenti nella tabella Genre. … … 
-- Effettuate tutte le query esplorative che vi servono per prendere confidenza con i dati.



-- QUERY per ottenere i nomi delle tabelle 

SELECT 
    TABLE_NAME
FROM
    information_schema.tables
WHERE
    TABLE_SCHEMA = 'chinook'; 
    
 -- seleziona le prime 10 righe    
SELECT 
    *
FROM
    album
    ORDER BY ArtistID
LIMIT 10;



SELECT 
    *
FROM
    track;

-- conta il numero totale di track univoche 

SELECT count(TrackId) as totale_canzoni FROM track ;

-- generi univoci in Genre 
SELECT DISTINCT Name FROM Genre;

SELECT 
    *
FROM
    invoice;
    
select * from mediatype;


-- Recuperate il nome di tutte le tracce e del genere associato.

select * from track;

select * from genre;
-- se limito a mille vedo solo il 1 
SELECT 
    track.Name, track.GenreId, genre.Name
FROM
    track
        JOIN
    genre ON track.genreId = genre.GenreId
    limit 2000;
    
    -- Recuperate il nome di tutti gli artisti che hanno almeno un album nel database. Esistono artisti senza album nel database?


select * from artist;

SELECT 
    *
FROM
    artist
        JOIN
    album ON artist.ArtistId = album.ArtistId;
    
-- provo a vedere se ci sono artisti senza album nella tabella album     
SELECT 
    *
FROM
    album
WHERE
    ArtistId NOT IN (SELECT 
            artistId
        FROM
            artist);
            
            
 -- Recuperate il nome di tutte le tracce, del genere associato e della tipologia di media.
 -- Esiste un modo per recuperare il nome della tipologia di media?      
 
 select * from track;
 
SELECT 
    track.Name, track.GenreId, genre.Name, mtype.Name
FROM
    track
        JOIN
    genre ON track.genreId = genre.GenreId
        JOIN
    mediatype as mtype ON mtype.MediaTypeId = track.MediaTypeId;


-- Elencate i nomi di tutti gli artisti e dei loro album.

select * from artist;

SELECT 
    artist.Name, album.Title
FROM
    artist
        JOIN
    album ON artist.ArtistId = album.ArtistId;



-- esercizio 1 W12 
-- recuperare tutte le tracce che abbiano come genere pop o rock 

select * from genre;

SELECT 
    track.Name, track.GenreId
FROM
    track
WHERE
    track.GenreId IN (SELECT 
            GenreId
        FROM
            genre
        WHERE
            GenreId = 9 OR GenreId = 3);

select GenreId from genre where GenreId = 9 or GenreId = 3;



-- Elencate tutti gli artisti e/o gli album che inizino con la lettera “A”.
-- https://www.w3schools.com/sql/trysql.asp?filename=trysql_select_union3 qui c'è il mio esempio 

SELECT DISTINCT
    UPPER(Title) as Titolo_NomeGruppo, ArtistId
FROM
    album
WHERE
    Title LIKE 'A%' 
UNION SELECT DISTINCT
    UPPER(Name) as NomeGruppo, ArtistId
FROM
    artist
WHERE
    Name LIKE 'A%';
    

-- Recuperate i nomi degli album o degli artisti che abbiano pubblicazioni precedenti all’anno 2000.
-- dove trovo le date???? ho usato un altra tabella. 

select * from employee where HireDate > 2000-01-01;


-- Elencate tutte le tracce che hanno come genere “Jazz” o che durano meno di 3 minuti.
SELECT 
    *
FROM
    track
WHERE
    Milliseconds < 18000
        OR GenreId IN (SELECT 
            GenreId
        FROM
            genre
        WHERE
            GenreId = 2);

-- confermo che ci sono GenreId diversi da Jazz ( 4 - 1 - 17) poiché durano meno di 3 minuti
SELECT 
    *
FROM
    track
WHERE
    Milliseconds < 18000;
    

-- Recuperate tutte le tracce più lunghe della durata media.

SELECT 
    Name, trackId
FROM
    track
WHERE
    Milliseconds > (SELECT 
            AVG(Milliseconds) AS avg_tempo
        FROM
            track); 
            
-- Individuate i generi che hanno tracce con una durata media maggiore di 4 minuti.

SELECT AVG(Milliseconds) as mtrack, GenreId
FROM track
GROUP BY GenreId
having mtrack > 240000;


-- Individuate gli artisti che hanno rilasciato più di un album. 
select * from album;

SELECT count(ArtistId) AS Num_Album, ArtistId
FROM album 
GROUP BY ArtistId
HAVING  Num_Album > 1;


-- Trovate la traccia più lunga in ogni album
select TrackId, AlbumId, Milliseconds from track where AlbumId in (select albumId from album);

SELECT 
    MAX(Milliseconds) as SongLongest, AlbumId
FROM
    track
GROUP BY AlbumId
HAVING AlbumId IN (SELECT 
        AlbumId
    FROM
        album);


select  AlbumId, Max(Milliseconds) from track group by AlbumId ;


-- Individuate la durata media delle tracce per ogni album.
select  AlbumId, AVG(Milliseconds) as durata_media from track group by AlbumId ;


-- Individuate gli album che hanno più di 20 tracce e mostrate il nome dell’album e il numero di tracce in esso contenute.

-- query per capire quali sono gli album che hanno più di 20 tracce e vede albumId 
SELECT  albumId, COUNT(AlbumId) AS Num_Track
FROM     Track
GROUP BY AlbumId
HAVING Num_Track > 20;
        
-- qui filtro sulla base della query precedente senza albumId
SELECT  AlbumId, Title
FROM album
UNION 
SELECT  albumId, COUNT(AlbumId) AS Num_Track
FROM     Track
GROUP BY AlbumId
HAVING Num_Track > 20;

select * from track;


-- finale 

SELECT album.Title, COUNT(track.AlbumId) AS NumeroTracce
FROM track
JOIN album ON album.AlbumId = Track.albumId
GROUP BY Album.Title
HAVING COUNT(track.AlbumId) > 20;


