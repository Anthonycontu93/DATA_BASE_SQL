-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: videogiochi
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `videogioco`
--

DROP TABLE IF EXISTS `videogioco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videogioco` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `titolo` text,
  `sviluppatore` tinytext,
  `anno_distribuzione` int DEFAULT NULL,
  `costo_acquisto` int DEFAULT NULL,
  `genere` text,
  `remakeDi` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videogioco`
--

LOCK TABLES `videogioco` WRITE;
/*!40000 ALTER TABLE `videogioco` DISABLE KEYS */;
INSERT INTO `videogioco` VALUES (1,'Fifa 2023                               ','EA Sports',2023,50,'Calcio',NULL),(2,'Assassin\'s Creed: Valhalla              ','Ubisoft',2020,60,'Action',NULL),(3,'Super Mario Odyssey                     ','Nintendo',2017,40,'Platform',NULL),(4,'The Last of Us Part II                  ','Naughty Dog',2020,70,'Action',NULL),(5,'Cyberpunk 2077                          ','CD Projekt Red5',2020,50,'RPG',NULL),(6,'Animal Crossing: New Horizons           ','Nintendo',2020,55,'Simulation',NULL),(7,'Call of Duty: Warzone                   ','Infinity Ward',2020,0,'FPS',NULL),(8,'The Legend of Zelda: Breath of the Wild ','Nintendo',2017,60,'Action-Adventure',NULL),(9,'Fortnite                                ','Epic Games',2017,0,'Battle Royale',NULL),(10,' Red Dead Redemption 2   				 ','Rockstar Games',2018,40,'Action-Adventure',NULL),(11,'Fifa 2023                               ','EA Sports',2023,50,'Calcio',NULL),(12,'Assassin\'s Creed: Valhalla              ','Ubisoft',2020,60,'Action',NULL),(13,'Super Mario Odyssey                     ','Nintendo',2017,40,'Platform',NULL),(14,'The Last of Us Part II                  ','Naughty Dog',2020,70,'Action',NULL),(15,'Cyberpunk 2077                          ','CD Projekt Red5',2020,50,'RPG',NULL),(16,'Animal Crossing: New Horizons           ','Nintendo',2020,55,'Simulation',NULL),(17,'Call of Duty: Warzone                   ','Infinity Ward',2020,0,'FPS',NULL),(18,'The Legend of Zelda: Breath of the Wild ','Nintendo',2017,60,'Action-Adventure',NULL),(19,'Fortnite                                ','Epic Games',2017,0,'Battle Royale',NULL),(20,' Red Dead Redemption 2   				 ','Rockstar Games',2018,40,'Action-Adventure',NULL),(21,'Fifa 2023                               ','EA Sports',2023,50,'Calcio',NULL),(22,'Assassin\'s Creed: Valhalla              ','Ubisoft',2020,60,'Action',NULL),(23,'Super Mario Odyssey                     ','Nintendo',2017,40,'Platform',NULL),(24,'The Last of Us Part II                  ','Naughty Dog',2020,70,'Action',NULL),(25,'Cyberpunk 2077                          ','CD Projekt Red5',2020,50,'RPG',NULL),(26,'Animal Crossing: New Horizons           ','Nintendo',2020,55,'Simulation',NULL),(27,'Call of Duty: Warzone                   ','Infinity Ward',2020,0,'FPS',NULL),(28,'The Legend of Zelda: Breath of the Wild ','Nintendo',2017,60,'Action-Adventure',NULL),(29,'Fortnite                                ','Epic Games',2017,0,'Battle Royale',NULL),(30,' Red Dead Redemption 2   				 ','Rockstar Games',2018,40,'Action-Adventure',NULL);
/*!40000 ALTER TABLE `videogioco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-08 20:59:11
