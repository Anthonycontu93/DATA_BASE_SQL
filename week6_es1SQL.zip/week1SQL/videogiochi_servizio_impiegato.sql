-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: videogiochi
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `servizio_impiegato`
--

DROP TABLE IF EXISTS `servizio_impiegato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servizio_impiegato` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `codice_fiscale` text NOT NULL,
  `codice_store` int NOT NULL,
  `data_inizio` date DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `carica` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servizio_impiegato`
--

LOCK TABLES `servizio_impiegato` WRITE;
/*!40000 ALTER TABLE `servizio_impiegato` DISABLE KEYS */;
INSERT INTO `servizio_impiegato` VALUES (1,'ABC12345XYZ67890',1,'2023-01-01','2023-12-31',' Carica                '),(2,'DEF67890XYZ12345',2,'2023-02-01','2023-11-30',' Cassiere              '),(3,'JKL67890XYZ12345',3,'2023-03-01','2023-10-31',' Commesso              '),(4,'MNO12345XYZ67890',4,'2023-04-01','2023-09-30',' Magazziniere          '),(5,'PQR67890XYZ12345',5,'2023-05-01','2023-08-31',' Addetto alle vendite  '),(6,'STU12345XYZ67890',6,'2023-06-01','2023-07-31',' Addetto alle pulizie  '),(7,'VWX67890XYZ12345 ',7,'2023-07-01','2023-06-30',' Commesso              '),(8,'YZA12345XYZ67890',8,'2023-08-01','2023-05-31',' Commesso     		  '),(9,'CD67890XYZ12345',9,'2023-09-01','2023-04-30',' Commesso     		  ');
/*!40000 ALTER TABLE `servizio_impiegato` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-08 20:59:12
