drop table store;

CREATE TABLE store (ID INTEGER not null PRIMARY KEY auto_increment, codice_store integer NOT NULL, indirizzo_fisico TEXT (60), numero_telefono TEXT (100));

alter table servizio_impiegato
drop column  nome;


 
INSERT INTO impiegato (codice_fiscale, nome, titolo_studio, recapito) 
VALUES ("ABC12345XYZ67890", "Mario Rossi", "Laurea in Economia", " mario.rossi@email.com"),
	   ("DEF67890XYZ12345", "Anna Verdi", "Diploma di Ragioneria", " anna.verdi@email.com "),
       ("JKL67890XYZ12345", "Luigi Bianchi","Laurea in Informatica", " luigi.bianchi@email.com "),
       ("MNO12345XYZ67890","Laura Neri","Laurea in Lingue", " laura.neri@email.com "),
       ("PQR67890XYZ12345", "Andrea Moretti", "Diploma di Geometra", " andrea.moretti@email.com"),
       ("STU12345XYZ67890","Giulia Ferrara",  "Laurea in Psicologia" ," giulia.ferrara@email.com"),
       ("VWX67890XYZ12345 ","Marco Esposito" , "Diploma di Elettronica" , " marco.esposito@email.com"),
       ("YZA12345XYZ67890", "Sara Romano" ,"Laurea in Giurisprudenza",  " sara.romano@email.com   "),
       ("CD67890XYZ12345", "Roberto De Luca" ,"Diploma di Informatica", " roberto.deluca@email.com");
       
CREATE TABLE impiegato (ID INTEGER not null PRIMARY KEY auto_increment, codice_fiscale integer NOT NULL, nome TEXT (60), titolo_studio TEXT (100), recapito TEXT (100));
    
select * from impiegato;

CREATE TABLE servizio_impiegato (ID INTEGER not null PRIMARY KEY auto_increment, codice_fiscale text NOT NULL, nome TEXT (60), codice_store integer NOT NULL, data_inizio date, data_fine date, carica TEXT (100));


INSERT INTO servizio_impiegato (codice_fiscale, codice_store, data_inizio, data_fine, carica) 
VALUES ("ABC12345XYZ67890", 1, " 2023-01-01", " 2023-12-31" , " Carica                "),
	   ("DEF67890XYZ12345", 2, " 2023-02-01", " 2023-11-30" , " Cassiere              "),
       ("JKL67890XYZ12345", 3, " 2023-03-01", " 2023-10-31" , " Commesso              "),
       ("MNO12345XYZ67890", 4, " 2023-04-01", " 2023-09-30" , " Magazziniere          "),
       ("PQR67890XYZ12345", 5, " 2023-05-01", " 2023-08-31" , " Addetto alle vendite  "),
       ("STU12345XYZ67890", 6, " 2023-06-01", " 2023-07-31" , " Addetto alle pulizie  "),
       ("VWX67890XYZ12345 ",7, " 2023-07-01", " 2023-06-30" , " Commesso              "),
       ("YZA12345XYZ67890", 8, " 2023-08-01", " 2023-05-31" , " Commesso     		  "),
       ("CD67890XYZ12345", 9,  " 2023-09-01", " 2023-04-30" , " Commesso     		  ");


select * from servizio_impiegato;

CREATE TABLE videogioco (ID INTEGER not null PRIMARY KEY auto_increment, titolo TEXT, sviluppatore TEXT (60), anno_distribuzione date, costo_acquisto INTEGER, genere TEXT (100), remakeDi text);

alter table videogioco 
modify anno_distribuzione INT;

INSERT INTO videogioco (titolo, sviluppatore, anno_distribuzione, costo_acquisto, genere) 
VALUES ("Fifa 2023                               " , "EA Sports"       , 2023 , 49.99, "Calcio"  ),
       ("Assassin's Creed: Valhalla              " , "Ubisoft"         , 2020, 59.99, "Action" ),
       ("Super Mario Odyssey                     " , "Nintendo"        , 2017, 39.99, "Platform"),
       ("The Last of Us Part II                  " , "Naughty Dog"     , 2020, 69.99, "Action"),
       ("Cyberpunk 2077                          " , "CD Projekt Red5" , 2020, 49.99, "RPG"),
       ("Animal Crossing: New Horizons           " , "Nintendo"        , 2020, 54.99, "Simulation"),
       ("Call of Duty: Warzone                   " , "Infinity Ward"   , 2020, 0.00 , "FPS"),
       ("The Legend of Zelda: Breath of the Wild " , "Nintendo"        , 2017, 59.99, "Action-Adventure"),
       ("Fortnite                                " , "Epic Games"      , 2017, 0.00 , "Battle Royale"),
       (" Red Dead Redemption 2   				 " , "Rockstar Games"  , 2018, 39.99, "Action-Adventure");
       
select * from videogioco;

select * 
from videogioco as vg inner join store  as negozio on vg.ID = negozio.codice_store;



       