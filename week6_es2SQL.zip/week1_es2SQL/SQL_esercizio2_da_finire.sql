CREATE TABLE Prodotti (
    ID_prodotto int auto_increment primary key,
    nome_prodotto varchar(255),
    prezzo varchar(255)
);


alter table Prodotti
modify prezzo int;

CREATE TABLE Clienti (
    ID_cliente int auto_increment primary key,
    nome varchar(255),
    email varchar(255)
);

CREATE TABLE Oridni (
    ID_odrdine int auto_increment primary key,
    quantita int,
    ID_prodotto int,
    ID_cliente int,
    FOREIGN KEY (ID_prodotto) REFERENCES Prodotti(ID_prodotto),
    FOREIGN KEY (ID_cliente) REFERENCES Clienti(ID_cliente)
);

INSERT INTO Prodotti ( nome_prodotto, prezzo ) 
VALUES ("Tablet " ,    300.00 )   ,
       (" Mouse " ,     20.00 )   ,
       (" Tastiera ",   25.00 )   ,
       (" Monitor " ,   180.00 )  ,
       (" HHD " ,       90.00 )   ,
       (" SSD " ,      200.00 )   ,
       (" RAM" ,       100.00 )   ,
       (" Router " ,    80.00 )   ,
       (" Webcam " ,     45.00 )  ,
       ("  GPU " ,     1250.00 )  ,
	   (" TrackPad" ,    500.00 ) ,
       (" TechMagazine " ,  5.00 ),
       ("  Martech " , 	 50.00 );
       

ALTER TABLE oridni RENAME ordini;

INSERT INTO oridni (ID_Prodotto, quantita) 
VALUES ( 2  , 10), 
	   ( 6  , 2 ),
	   ( 5  , 3 ),
	   ( 1  , 1 ),
	   ( 9  , 1 ),
	   ( 4  , 2 ),
	   ( 11 , 6 ),
	   ( 10 , 2 ),
	   ( 3  , 3 ),
	   ( 3 , 1 ),
	   ( 2 , 1 );
       
       
       
CREATE TABLE dettaglioOrdini (
    ID_odrdine int,
    ID_prodotto int,
    ID_cliente int,
    FOREIGN KEY (ID_odrdine) REFERENCES ordini(ID_odrdine),
    FOREIGN KEY (ID_prodotto) REFERENCES Prodotti(ID_prodotto),
    FOREIGN KEY (ID_cliente) REFERENCES Clienti(ID_cliente)
);




INSERT INTO Clienti ( nome, email)
VALUES 
( "Antonio ", null),
( "Battista" ,  " battista@mailmail.it" ),
( "Maria" , "maria@posta.it " ),
( "Franca ", " franca@lettere.it" ),
( "Ettore  ", null),
( "Arianna " , " arianna@posta.it  " ),
( "Piero " , "piero@lavoro.it   ");



INSERT INTO dettaglioOrdini(ID_odrdine, ID_prodotto, ID_cliente) 
VALUES (1, 2 , 1), 
	   (2, 6 , 2 ),
	   (3, 1 , 3 ),
	   (4, 10, 7);

-- to make it works you need to check you father table (Clienti --> column ID_Cliente) check if there is any and then only then you can popolate dettagliOrdini with the same value of ordini Prodotti Clienti; 
-- se non esiste il valore nelle tabelle padri allora non possono esistere altrove;
select * from clienti;
    
select * from clienti as c join ordini as o on c.ID_cliente = o.ID_odrdine; 