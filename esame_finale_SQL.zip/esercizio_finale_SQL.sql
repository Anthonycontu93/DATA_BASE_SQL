CREATE TABLE Product (
    Product_ID INT NOT NULL AUTO_INCREMENT,
    lotto VARCHAR(255) NOT NULL,
    category VARCHAR(255),
    price FLOAT4,
    PRIMARY KEY (Product_ID)
);


CREATE TABLE Sales (
    Sales_ID INT NOT NULL AUTO_INCREMENT,
    ordine_data DATETIME DEFAULT CURRENT_TIMESTAMP,
    quantity VARCHAR(255),
    tot FLOAT,
    Product_ID INT,
    Region_ID INT,
    PRIMARY KEY (Sales_ID),
    FOREIGN KEY (Product_ID)
        REFERENCES Product (Product_ID),
    FOREIGN KEY (Region_ID)
        REFERENCES Region (Region_ID)
);


CREATE TABLE Region (
    Region_ID INT NOT NULL AUTO_INCREMENT,
    Seller_ID INT,
    geo_area VARCHAR(255),
    cap VARCHAR(255),
    PRIMARY KEY (Region_ID),
    FOREIGN KEY (Seller_ID)
        REFERENCES Seller (Seller_ID)
);


CREATE TABLE Seller (
    Seller_ID INT NOT NULL AUTO_INCREMENT,
    sconto INT,
    cliente VARCHAR(255),
    tot_vendita FLOAT,
    stato_fattura VARCHAR(255),
    PRIMARY KEY (Seller_ID)
);




INSERT INTO product (lotto, category, price) 
VALUES ("4561", "Tablet", 300),
       ("J450", "Mouse", 20 ),
       ("J450", "Tastiera", 25),
       ("J445","Monitor" , 180 ),
       ("J445", "HHD" , 90)   ,
       ("4561","SSD" , 200 )   ,
       ("J450", "RAM" , 100)   ,
       ("J4k9","Router" , 80)   ,
       ("JHJ0","Webcam" , 45 )  ,
       ("J450","GPU" , 1250)  ,
	   ("4561"," TrackPad" , 500 ) ,
       ("J450","TechMagazine" , 5 ),
       ("J450","Martech" , 50 );

SELECT 
    *
FROM
    product;


INSERT INTO region (Seller_ID, geo_area, cap) 
VALUES (1,"Nord", "ASDF"),
       (1,"sud", "ASXN"),
       (3,"sud", "ASGH"),
       (2,"nord","MNKL"),
       (2, "nord", "SGDY");

INSERT INTO Seller (sconto, cliente, tot_vendita, stato_fattura) 
VALUES (10,"ikea", 15000, "pagato"),
       (10,"ikea", 25000, "outstanding"),
       (30,"nike", 25000, "pagato"),
       (20,"adidas",5000, "outstanding"),
       (20, "Puma", 152000, "outstanding");       
       
INSERT INTO sales (quantity, tot, Product_ID, Region_ID) 
VALUES (50,7566, 3, 2),
       (40,9800, 3, 2),
       (80,7000, 1, 3),
       (150, 85000, 3, 2),
       (45, 4500, 2, 1);
       

SELECT 
    *
FROM
    seller;

SELECT 
    *
FROM
    sales;

SELECT 
    *
FROM
    region;

SELECT 
    *
FROM
    product;


-- Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a:
-- 1. Verificare che i campi definiti come PK siano univoci. 
-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT 
    *
FROM
    sales;
-- query per 2° richiesta 
SELECT 
    Product_ID,
    YEAR(ordine_data) AS anno,
    SUM(tot) AS totale_venduto_per_Anno,
    SUM(quantity) AS tot_quantità
FROM
    sales
GROUP BY Product_ID , anno
;

-- query per 3° richiesta 
CREATE VIEW sell_region (region_id , geo_area) AS
    SELECT 
        Region_ID, geo_area
    FROM
        region;
        
SELECT 
    *
FROM
    sell_region;

CREATE VIEW sell_area (region_id , anno , tot_venduto , tot_q) AS
    SELECT 
        Region_ID,
        YEAR(ordine_data) AS anno,
        SUM(tot) AS totale_venduto_per_Anno,
        SUM(quantity) AS tot_quantità
    FROM
        sales
    GROUP BY Region_ID , anno;
    
SELECT 
    *
FROM
    sell_area ;
    
-- query innestata per trovare gli ID regioni con vendite 
SELECT 
    *
FROM
    sell_area
WHERE
    region_id IN (SELECT 
            region_id
        FROM
            sell_region)
ORDER BY anno DESC , tot_venduto DESC
;

-- query 4° richiesta 
SELECT 
    *
FROM
    sales;
SELECT 
    Product_ID, COUNT(Product_ID) AS prodotto_più_richiesto
FROM
    sales
GROUP BY Product_ID
ORDER BY prodotto_più_richiesto DESC
LIMIT 1
;

-- query 5° richiesta
-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- primo modo 
SELECT Product_ID FROM sales;
SELECT * FROM product where product_ID not in (SELECT Product_ID FROM sales);

-- secondo modo 
CREATE VIEW prodotti_venduti(product_id) as SELECT Product_ID FROM sales;
select * FROM prodotti_venduti;

SELECT DISTINCT * FROM prodotti_venduti LEFT JOIN sales ON prodotti_venduti.product_id = sales.Product_ID;

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)

INSERT INTO sales (quantity, tot, Product_ID, Region_ID) 
VALUES (10,1456, 3, 1),
       (23,5640, 3, 1);

-- dopo qualche minuto
INSERT INTO sales (quantity, tot, Product_ID, Region_ID) 
VALUES (2,100, 3, 3),
       (6,540, 2, 2);
       
select * from sales ;

SELECT 
    Product_ID,
    DAY(ordine_data) AS giorno_vendita,
    TIME(ordine_data) AS ora_vendita
FROM
    sales
ORDER BY giorno_vendita DESC , ora_vendita DESC;


